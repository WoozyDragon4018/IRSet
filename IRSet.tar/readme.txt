IRSET - The NewGRF Set based on the Majestic Indian Railways!
This is a set created with the help of these guys:
CODERS: WOOZYDRAGON4018
SPRITERS: ROTTERDXM, SOMEINDIANGUY99, PURNO, WOOZYDRAGON4018.
HELPERS: AZUSA, SEAN | SPNDA, CHRIS (ERATO).

Please enjoy our latest version, 0.0.8 Pre Alpha. 
We are constantly working on more and more trains to update frequently.
It is 0.0.8, it might reach 1.0 in a couple of days!
We are continuously working on this project since 2017, but now it has been coded for the first time!

Thank you,
Sincerely, the IRSet Team!
